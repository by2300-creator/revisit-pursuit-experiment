# Study Introduction

In this study, you will view short animations of several colored moving dots. In every trial, one dot (the **chaser**) will be actively pursuing another dot (the **prey**).

Your task is to identify both the **chaser (C)** and the **prey (P)** as quickly and accurately as possible.
