**Colors:** Any color can be the chaser or the prey, and the colors will change from trial to trial.

**Making your selection:** Click directly on the dot you think is the chaser and the dot you think is the prey.

**Overlapping dots:** If multiple dots overlap where you click, choose your intended color from the pop-up options. Once the motion stops, a keyboard and color-selection menu will also be available to enter your response.
