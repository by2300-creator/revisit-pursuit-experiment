# Thank you!

You have completed the study.

Select **Finish and download data** to save your results. Keep the downloaded file and return it to the experimenter using the agreed method. This pilot does not automatically send results to the research team.

Please wait for the download before closing this page.
