# Practice before the study

You will complete **20 training trials**, followed by **30 formal trials** and one brief instruction check.

Watch the six colored dots until they stop. Then **click the dot you think is the chaser**, followed by **the dot you think is its prey**. Choose two different dots. You can use **Choose chaser**, **Choose prey**, or **Clear selections** to revise your answer before submitting.

Rate your confidence from **1** (not confident) to **4** (very confident). During training, select **Check training answer**. Feedback will tell you whether each choice was correct and reveal the correct chaser and prey with green **C** and **P** markers. Select **Continue** after reviewing the feedback.

If dots overlap at the point you click, choose the intended color from the options shown. A keyboard/color-selection alternative is also available after motion stops.

Dot colors do not identify their roles. Some displays have short or long traces on all dots. Training and formal trials use different motion examples, with the same applied speed, chasing, and video-duration settings.

Training answers are recorded separately from formal answers. You can take a break after training.


Before each display, look at the small point in the center. When it disappears, watch the moving dots freely. The point lasts 750 milliseconds and is separate from the motion viewing time.
