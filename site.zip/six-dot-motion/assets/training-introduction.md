# Practice

1. Look at the center point, then watch the dots.
2. When they stop, select the **chaser**, then its **prey**.
3. Rate your confidence from **1 — not confident** to **5 — very confident**.
4. Select **Check training answer** to see the correct pair, then **Continue**.

You will complete 20 practice trials, followed by 30 main trials and two attention checks. Colors do not indicate roles.
