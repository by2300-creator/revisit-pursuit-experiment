The next **two practice trials** will help you get used to the motion and how to respond.

After each one, choose the chaser and the prey, rate your confidence, and select **Check practice answer** to see the correct pair. Then select **Continue**.

Select **Start practice** when you are ready.
