## Take a break

You have completed 10 of 30 main trials. Rest as long as you like. Select Resume when you are ready.
