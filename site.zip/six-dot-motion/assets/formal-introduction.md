# Main study

Identify the chaser and prey, then rate your confidence on each trial. There is no correctness feedback.

You may rest now. Keep your head and browser window steady when you continue.
