# Training complete

You have completed the **20 training trials**. Take a short break if you need one.

The formal study has **30 trials** with different motion examples, plus one instruction check after the first 15 formal trials. After each display stops, **click the chaser, then its prey**, and select your confidence.

Formal trials do not reveal the correct pair or show correctness feedback. Once you have selected two different dots and your confidence, select **Next stimulus** to continue.

Select **Start formal trials** when ready.


Before each display, look at the small point in the center. When it disappears, watch the moving dots freely. The point lasts 750 milliseconds and is separate from the motion viewing time.
