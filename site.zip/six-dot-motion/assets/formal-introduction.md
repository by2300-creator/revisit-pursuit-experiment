## Main trials

Thank you for completing the practice trials. You will now complete 30 main trials without feedback. Identify the chaser and prey as quickly and accurately as you can, then rate your confidence.

Keep your eyes on the screen while the dots are moving. You can rest after main trials 10 and 20. Select **Start main trials** when you are ready.
