The session includes **5 practice trials**, followed by **30 main trials** and a few brief demographic questions.
