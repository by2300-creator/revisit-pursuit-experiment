## Take a break

You have completed 20 of 30 main trials. Rest as long as you like. Select Resume when you are ready.
