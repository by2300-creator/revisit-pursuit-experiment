## How to respond

Look at the center point. When it disappears, watch how the dots move. Any color can be the chaser or the prey, and the colors assigned to those roles can change each trial.

1. When the dots stop, click the **chaser** first, then the **prey**.
2. If dots overlap where you click, choose the color you meant from the options that appear. You can also open **Keyboard or color selection** below the dots. Use the mouse, or press Tab to reach a color and Enter to select it.
3. Rate how confident you are that you identified both dots.

**1** — not confident  
**2** — slightly confident  
**3** — moderately confident  
**4** — confident  
**5** — very confident
