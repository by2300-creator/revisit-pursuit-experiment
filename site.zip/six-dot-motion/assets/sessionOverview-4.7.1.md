The session includes **5 practice trials**, followed by **30 main trials** and two brief attention checks. Please complete the trials in one sitting.
