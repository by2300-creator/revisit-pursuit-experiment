**Introduction to Practice Trials**

Before starting the main experiment, you will complete five practice trials to get used to how the dots move and how to submit your answers.

Press **[Spacebar / Next]** when you are ready to begin the practice trials.
