## What to expect

You will complete **2 practice trials** with feedback. The main study has **30 trials** and two additional short checks. You can take a break after main trials 10 and 20.

After the trials, you can answer a few optional questions about yourself.
