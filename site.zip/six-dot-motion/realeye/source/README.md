# Six-dot pursuit study 4.2.0
The camera module uses RealEye Light Open 1.1.0, commit d94850fa01f50087d5e51d24d741bc78f61ded64. The lib directory contains its TypeScript source. The enclosing experiment supplies the target UI, validation and per-trial recorder. The site serves its model and MediaPipe runtime locally.

To rebuild camera.js from this directory, install @mediapipe/tasks-vision@0.10.18, ml-matrix@6.12.1 and esbuild@0.28.2, then run:

    npx esbuild camera.js --bundle --format=esm --outfile=../camera.js

integrate.py reproduces the tracker changes to the study shell. Run it from a working directory containing the original release 30bdb31 site.zip unpacked under site/. It expects the original bundle and stops on an unexpected replacement. Then run calibration-update.py from the same working directory. Include the realeye folder in the new release.

The participant chooses Enable camera and calibrate and clicks one target at each of 17 positions. After each click, the tracker waits 450 ms and collects four face-detected frames with open eyes. Five separate targets measure median gaze error before trial recording. The browser discards calibration frames after fitting. The eyeTracking JSON field identifies the tracker version and commit, reports missing samples and validation results, and stores viewport and canvas coordinates aligned with trial phase, displayed dot positions and simulation time. Calibration click coordinates use CSS viewport pixels. The current pilot stores behavioral and gaze data together in the ReVISit export. Validate the saved data with a person before using it to assign gaze to individual dots.
