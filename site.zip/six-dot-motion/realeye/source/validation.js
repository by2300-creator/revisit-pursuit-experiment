// Measure prediction error against the rendered target in viewport CSS pixels.
export function measureTarget(subscribe, element, done) {
  const rect = element.getBoundingClientRect();
  const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
  const start = performance.now(), errors = [];
  let callbacks = 0, finished = false;
  const unsubscribe = subscribe(gaze => {
    if (finished || performance.now() - start < 750) return;
    callbacks++;
    if (gaze && Number.isFinite(gaze.x) && Number.isFinite(gaze.y)) {
      errors.push(Math.hypot(gaze.x-x, gaze.y-y));
    }
  });
  function finish() {
    if (finished) return;
    finished = true;
    unsubscribe();
    clearInterval(timer);
    errors.sort((a,b) => a-b);
    const mid = Math.floor(errors.length/2);
    const median = errors.length ? (errors[mid] + errors[Math.floor((errors.length-1)/2)])/2 : null;
    done({x, y, sampleCount:errors.length, medianErrorPx:median, callbacks, durationMs:Math.round(performance.now()-start)});
  }
  const timer = setInterval(() => {
    const elapsed = performance.now()-start;
    if ((elapsed >= 2400 && errors.length >= 8) || elapsed >= 6500) finish();
  },100);
  return () => { finished = true; clearInterval(timer); unsubscribe(); };
}

export function resultMessage(check) {
  const sparse = check.points.filter(p => p.sampleCount < check.minSamplesPerPoint);
  const off = check.points.filter(p => p.sampleCount >= check.minSamplesPerPoint && p.medianErrorPx > check.maxMedianErrorPx);
  const names = ['center','upper left','upper right','lower right','lower left'];
  const summary = [];
  if (!sparse.length && !off.length) summary.push('Calibration passed. Keep your head and window in the same position.');
  if (sparse.length) summary.push('Too few usable gaze readings at ' + sparse.map(p => names[check.points.indexOf(p)]+' ('+p.sampleCount+'/'+check.minSamplesPerPoint+')').join(', ') + '. Face the camera in even light and keep both eyes visible.');
  if (off.length) summary.push('Gaze missed the target at ' + off.map(p => names[check.points.indexOf(p)]+' ('+Math.round(p.medianErrorPx)+' px)').join(', ') + '. Allowed median error: '+Math.round(check.maxMedianErrorPx)+' px. Keep looking at each dot until it moves.');
  return summary.join(' ');
}
