from pathlib import Path
import json, hashlib
root=Path('site')
bundle=next((root/'assets').glob('index-*.js'))
s=bundle.read_text()
def rep(old,new):
    global s
    assert s.count(old)==1, old
    s=s.replace(old,new)
def span(first,last,replacement):
    rep(s[s.index(first):s.index(last,s.index(first))], replacement)
span('let GM=null;const ABe=', 'class Izt{','let realEyeTargets=[];')
span('const t=++this.generation,n=await Azt();','subscribe(t){', '''
const generation = ++this.generation;
let timer;
try {
  const {RealEyeCamera, targets} = await import(new URL(ri + "six-dot-motion/realeye/camera.js",document.baseURI).href);
  if (generation !== this.generation) return;
  realEyeTargets = targets;
  const camera = new RealEyeCamera((gaze, elapsed) => this.listeners.forEach(fn => fn(gaze, elapsed)));
  this.engine = camera;
  await Promise.race([camera.begin(), new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error("Camera startup timed out. Check the camera permission and retry.")), 60000);
  })]);
  if (generation === this.generation) this.active = true;
} catch (error) {
  if (generation === this.generation) { this.stop(); this.lastError = String(error.message || error); }
  throw error;
} finally { clearTimeout(timer); }
}
''')
rep('train(t,n){this.engine?.recordScreenPosition(t,n,"click")}', 'train(x,y,last){this.engine.capture(x,y,last)}')
rep('this.engine&&jq(this.engine)','this.engine?.close()')
rep('version:1,provider:"webgazer"', 'version:2,provider:"realeye-light-open",providerVersion:"1.1.0",providerCommit:"d94850fa01f50087d5e51d24d741bc78f61ded64",calibrationPattern:"GRID_17"')
span(',Rzt=[[.1,.1]',',Bq=[[.5,.5]', '')
rep('?Rzt:Bq','?realEyeTargets:Bq')
rep('Look directly at the point and click it ${5-d} more times. Point ${u+1} of 9.', 'Look directly at the point, then click it. Point ${u+1} of ${realEyeTargets.length}.')
rep('Pr.train(R.left+R.width/2,R.top+R.height/2),d<4?f(d+1):(f(0),u<8?c(u+1):(c(0),l("validate")))', '''const last = u === realEyeTargets.length - 1;
try {
  Pr.train(R.left+R.width/2,R.top+R.height/2,last);
  p("");
  if(last){c(0);l("validate")}else{c(u+1)}
} catch(error) {
  p(String(error.message || error));
  if(last){Pr.stop();l("consent")}
}''')
rep('y.jsx("p",{children:"Keep your head still. Only your gaze estimates', 'h&&y.jsx("p",{role:"alert",children:h}),y.jsx("p",{children:"Keep your head still. Only your gaze estimates')
rep('Requires the approved, locally hosted WebGazer bundle and HTTPS or localhost.', 'RealEye Light Open runs in this browser on HTTPS or localhost. Calibrate at 17 points, then follow the five validation targets.')
rep('children:"Optional eye tracking"', 'children:"Optional RealEye webcam tracking"')
rep('pursuit-detailed-v2','pursuit-detailed-v3')
target=bundle.with_name('index-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js')
target.write_text(s)
index=root/'index.html'
assert bundle.name in index.read_text()
index.write_text(index.read_text().replace(bundle.name,target.name))
bundle.unlink()
config=root/'six-dot-motion/config.json'
data=json.loads(config.read_text(encoding='utf-8-sig'))
data['studyMetadata']['version']='4.1.0'
data['studyMetadata']['date']='2026-11-23'
config.write_text(json.dumps(data,indent=2)+'\n')
