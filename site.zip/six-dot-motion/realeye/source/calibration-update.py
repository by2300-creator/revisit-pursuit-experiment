from pathlib import Path
import json,hashlib
root=Path('site');bundle=next((root/'assets').glob('index-*.js'));s=bundle.read_text()
def rep(old,new):
 global s
 assert s.count(old)==1,old
 s=s.replace(old,new)
def span(first,last,new):
 pos=s.index(first)
 rep(s[pos:s.index(last,pos)],new)
rep('realeye/camera.js?webcam=2','realeye/camera.js?calibration=2')
rep('train(x,y,last){this.engine.capture(x,y,last)}','train(x,y,last){return this.engine.capture(x,y,last)}')
rep('v=A.useRef([]),b=A.useRef(!1),x=A.useRef(0);','v=A.useRef([]),b=A.useRef(!1),x=A.useRef(0),targetRef=A.useRef(null),captureLock=A.useRef(false);')
rep('const C=()=>{Pr.stop(),l("consent")','const C=()=>{x.current++;captureLock.current=false;f(0);Pr.stop(),l("consent")')
span('const[C,E]=Bq[u],k=C*window.innerWidth', '},[a,u]);const S=', '''
const engine=Pr.engine;
return engine.measureTarget(listener=>Pr.subscribe(listener),targetRef.current,point=>{
  v.current.push(point);
  if(u<Bq.length-1){c(u+1);return}
  const report=TBe(v.current,[window.innerWidth,window.innerHeight]);
  report.protocol="realeye-multiframe-v2";
  report.trainingPoints=engine.trainingPoints.slice();
  Pr.calibrationAttempts.push(report); Pr.calibration=report; Pr.pause();
  g(report.passed); l("result"); p(engine.resultMessage(report));
});
''')
rep('const S=async()=>{const C=++x.current;', 'const S=async()=>{captureLock.current=false;f(0);const C=++x.current;')
rep('Look directly at the point, then click it. Point ${u+1} of ${realEyeTargets.length}.','Click the dot and keep looking at its center until it moves. Point ${u+1} of ${realEyeTargets.length}.')
rep('Keep looking at the point without clicking. Checking','Follow the dot with your eyes until it moves. No clicks. Checking')
rep('h&&y.jsx("p",{role:"alert",children:h}),y.jsx','d?y.jsx("p",{role:"status",children:"Hold your gaze on the dot…"}):h&&y.jsx("p",{role:"alert",children:h}),y.jsx')
span('"aria-label":"Calibration point",onClick:k=>{','},style:{position:"absolute",left:', '''"aria-label":"Calibration point",disabled:!!d,onClick:async k=>{
  if(captureLock.current)return;
  captureLock.current=true;
  const token=x.current,rect=k.currentTarget.getBoundingClientRect();
  f(1); p("");
  try{
    const last=u===realEyeTargets.length-1;
    await Pr.train(rect.left+rect.width/2,rect.top+rect.height/2,last);
    if(!b.current||token!==x.current)return;
    if(last){c(0);l("validate")}else c(u+1);
  }catch(error){
    if(b.current&&token===x.current)p(String(error.message||error));
  }finally{
    if(b.current&&token===x.current){captureLock.current=false;f(0)}
  }
''')
rep('"aria-label":"Validation point",style:', '"aria-label":"Validation point",ref:targetRef,style:')
rep('background:"#d55e00",cursor:"pointer"','background:d?"#177252":"#d55e00",cursor:"pointer",backgroundImage:"radial-gradient(circle,#111 0 2px,transparent 3px)"')
new=bundle.with_name('index-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js')
new.write_text(s);idx=root/'index.html';idx.write_text(idx.read_text().replace(bundle.name,new.name));bundle.unlink()
p=root/'six-dot-motion/config.json';v=json.loads(p.read_text());v['studyMetadata']['version']='4.2.0';p.write_text(json.dumps(v,indent=2)+'\n')
