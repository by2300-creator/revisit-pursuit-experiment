import { requestCamera, selectedCamera, rememberCamera } from './device.js';
import { WebcamETLight, getRecommendedPattern, getCalibrationPoints } from './lib/index.ts';

export const targets = getCalibrationPoints(getRecommendedPattern()).map(({x,y}) => [x,y]);

async function openWebcam() {
  const preferred = selectedCamera();
  try {
    if (preferred) {
      try { return await requestCamera(preferred); }
      catch (error) {
        if (!['NotFoundError', 'OverconstrainedError'].includes(error.name)) throw error;
        rememberCamera('');
      }
    }
    return await requestCamera();
  } catch (error) {
    const messages = {
      NotFoundError: 'This browser could not find a webcam. Open the study directly in a browser on the computer with your webcam. Check that your camera works in the computer’s Camera app, close that app, then try again.',
      OverconstrainedError: 'The browser could not open a compatible camera. Select another webcam in your browser’s camera settings, then try again.',
      NotAllowedError: 'Camera access was denied. Allow the camera for this site in your browser and enable camera access for your browser in system settings, then try again.',
      NotReadableError: 'The browser found a webcam but could not start it. Close other apps or tabs using the camera, then try again.'
    };
    if (messages[error.name]) throw new DOMException(messages[error.name], error.name);
    throw error;
  }
}

export class RealEyeCamera {
  constructor(onEstimate) {
    this.onEstimate = onEstimate;
    this.samples = [];
    this.video = document.createElement('video');
    this.video.muted = true;
    this.video.playsInline = true;
    this.canvas = document.createElement('canvas');
    this.context = this.canvas.getContext('2d', {willReadFrequently: true});
    this.started = performance.now();
  }
  async begin() {
    const stream = await openWebcam();
    if (this.closed) { stream.getTracks().forEach(track => track.stop()); return; }
    this.video.srcObject = stream;
    await this.video.play();
    if (this.closed) return;
    const base = new URL('.', import.meta.url);
    const tracker = new WebcamETLight({delegate: 'CPU', runningMode:'IMAGE',
      modelPath: new URL('face_landmarker.task', base).href, wasmPath: new URL('wasm', base).href});
    try {
      await tracker.initialize();
      if (this.closed) { tracker.dispose(); return; }
      this.tracker = tracker;
    } catch (error) { tracker.dispose(); throw error; }
  }
  frame() {
    const {video,canvas,context} = this;
    if (video.readyState < 2 || !video.videoWidth) throw new Error('Waiting for a camera frame. Try again.');
    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
      canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    }
    context.drawImage(video,0,0);
    return context.getImageData(0,0,canvas.width,canvas.height);
  }
  capture(x,y,last) {
    const image = this.frame();
    if (!this.tracker.detectFace(image)) throw new Error('Face not detected. Face the webcam and click the target again.');
    this.samples.push({image,gazeX:x,gazeY:y});
    if (last) {
      try { this.tracker.calibrate(this.samples); }
      finally { this.samples.length = 0; }
      this.resume();
    }
  }
  resume() {
    if (this.running || !this.tracker?.isCalibrated() || this.closed) return;
    this.running = true;
    let previousTime = -1;
    const tick = () => {
      if (!this.running) return;
      if (this.video.currentTime !== previousTime && this.video.readyState >= 2) {
        previousTime = this.video.currentTime;
        let gaze = null;
        try { gaze = this.tracker.predict(this.frame()); } catch { /* Retain dropped estimates as missing. */ }
        this.onEstimate(gaze,performance.now()-this.started);
      }
      this.animation = requestAnimationFrame(tick);
    };
    this.animation = requestAnimationFrame(tick);
  }
  pause() { this.running = false; cancelAnimationFrame(this.animation); }
  close() {
    this.closed = true;
    this.pause();
    this.video.srcObject?.getTracks().forEach(track => track.stop());
    this.video.srcObject = null;
    this.samples.length = 0;
    this.tracker?.dispose();
    this.tracker = null;
    this.canvas.width = 0;
  }
}
