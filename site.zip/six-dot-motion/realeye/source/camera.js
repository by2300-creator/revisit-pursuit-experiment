import { measureTarget, resultMessage } from './validation.js';
import { requestCamera, selectedCamera, rememberCamera } from './device.js';
import { WebcamETLight, getRecommendedPattern, getCalibrationPoints } from './lib/index.ts';

export const targets = getCalibrationPoints(getRecommendedPattern()).map(({x,y}) => [x,y]);

async function openWebcam() {
  const preferred = selectedCamera();
  try {
    if (preferred) {
      try { return await requestCamera(preferred); }
      catch (error) {
        if (!['NotFoundError', 'OverconstrainedError'].includes(error.name)) throw error;
        rememberCamera('');
      }
    }
    return await requestCamera();
  } catch (error) {
    const messages = {
      NotFoundError: 'This browser could not find a webcam. Open the study directly in a browser on the computer with your webcam. Check that your camera works in the computer’s Camera app, close that app, then try again.',
      OverconstrainedError: 'The browser could not open a compatible camera. Select another webcam in your browser’s camera settings, then try again.',
      NotAllowedError: 'Camera access was denied. Allow the camera for this site in your browser and enable camera access for your browser in system settings, then try again.',
      NotReadableError: 'The browser found a webcam but could not start it. Close other apps or tabs using the camera, then try again.'
    };
    if (messages[error.name]) throw new DOMException(messages[error.name], error.name);
    throw error;
  }
}

export class RealEyeCamera {
  constructor(onEstimate) {
    this.onEstimate = onEstimate;
    this.samples = [];
    this.video = document.createElement('video');
    this.video.muted = true;
    this.video.playsInline = true;
    this.canvas = document.createElement('canvas');
    this.context = this.canvas.getContext('2d', {willReadFrequently: true});
    this.started = performance.now();
    this.trainingPoints = [];
    this.measureTarget = measureTarget;
    this.resultMessage = resultMessage;
  }
  async begin() {
    const stream = await openWebcam();
    if (this.closed) { stream.getTracks().forEach(track => track.stop()); return; }
    this.video.srcObject = stream;
    await this.video.play();
    if (this.closed) return;
    const base = new URL('.', import.meta.url);
    const tracker = new WebcamETLight({delegate: 'CPU', runningMode:'IMAGE',
      modelPath: new URL('face_landmarker.task', base).href, wasmPath: new URL('wasm', base).href});
    try {
      await tracker.initialize();
      if (this.closed) { tracker.dispose(); return; }
      this.tracker = tracker;
    } catch (error) { tracker.dispose(); throw error; }
  }
  frame() {
    const {video,canvas,context} = this;
    if (video.readyState < 2 || !video.videoWidth) throw new Error('Waiting for a camera frame. Try again.');
    const scale = Math.min(1, Math.sqrt(640 * 480 / (video.videoWidth * video.videoHeight)));
    const width = Math.round(video.videoWidth * scale), height = Math.round(video.videoHeight * scale);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width; canvas.height = height;
    }
    context.drawImage(video,0,0,width,height);
    return context.getImageData(0,0,width,height);
  }
  async capture(x,y,last) {
    const wait = ms => new Promise(resolve => setTimeout(resolve,ms));
    const start = performance.now(), batch = [];
    let previousTime = this.video.currentTime;
    await wait(450);
    while (batch.length < 4 && performance.now() - start < 5000) {
      if (this.closed) throw new Error('Calibration cancelled.');
      const time = this.video.currentTime;
      if (time !== previousTime && this.video.readyState >= 2) {
        previousTime = time;
        const image = this.frame();
        const face = this.tracker.detectFace(image);
        if (face && !(face.blendshapes?.eyeBlinkLeft > 0.5 || face.blendshapes?.eyeBlinkRight > 0.5)) {
          batch.push({image, gazeX:x, gazeY:y});
        }
      }
      if (batch.length < 4) await wait(140);
    }
    if (this.closed) throw new Error('Calibration cancelled.');
    if (batch.length < 4) throw new Error('Too few clear eye readings. Face the camera in even light, then click this same point and keep looking at it.');
    this.samples.push(...batch);
    this.trainingPoints.push({x, y, sampleCount:batch.length, durationMs:Math.round(performance.now()-start)});
    if (last) {
      try { this.tracker.calibrate(this.samples); }
      catch (error) {
        this.samples.splice(-batch.length);
        this.trainingPoints.pop();
        throw error;
      }
      this.samples.length = 0;
      this.resume();
    }
  }
  resume() {
    if (this.running || !this.tracker?.isCalibrated() || this.closed) return;
    this.running = true;
    let previousTime = -1;
    const tick = () => {
      if (!this.running) return;
      if (this.video.currentTime !== previousTime && this.video.readyState >= 2) {
        previousTime = this.video.currentTime;
        let gaze = null;
        try { gaze = this.tracker.predict(this.frame()); } catch { /* Retain dropped estimates as missing. */ }
        this.onEstimate(gaze,performance.now()-this.started);
      }
      this.animation = requestAnimationFrame(tick);
    };
    this.animation = requestAnimationFrame(tick);
  }
  pause() { this.running = false; cancelAnimationFrame(this.animation); }
  close() {
    this.closed = true;
    this.pause();
    this.video.srcObject?.getTracks().forEach(track => track.stop());
    this.video.srcObject = null;
    this.samples.length = 0;
    this.tracker?.dispose();
    this.tracker = null;
    this.canvas.width = 0;
  }
}
