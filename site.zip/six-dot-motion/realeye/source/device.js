const preference = 'six-dot-motion.webcam';
export function selectedCamera() {
  try { return sessionStorage.getItem(preference) || ''; } catch { return ''; }
}
export function rememberCamera(id) {
  try {
    if (id) sessionStorage.setItem(preference, id);
    else sessionStorage.removeItem(preference);
  } catch { /* Storage can be unavailable in a restricted browser. */ }
}
export async function listCameras() {
  const inputs = await navigator.mediaDevices.enumerateDevices();
  return inputs.filter(input => input.kind === 'videoinput');
}
export async function requestCamera(id = '') {
  const devices = navigator.mediaDevices;
  if (!devices?.getUserMedia) throw new Error('Webcam access is unavailable in this browser. Open this HTTPS page directly in Chrome or Edge on the computer with your webcam.');
  const dimensions = {width: {ideal: 640}, height: {ideal: 480}};
  const capture = video => devices.getUserMedia({audio: false, video});
  const missing = e => ['NotFoundError','OverconstrainedError'].includes(e.name);
  if (id) return capture({...dimensions, deviceId: {exact: id}});
  try {
    return await capture({...dimensions, facingMode: {ideal: 'user'}});
  } catch (error) { if (!missing(error)) throw error; }
  try {
    return await capture(true);
  } catch (error) {
    if (!missing(error)) throw error;
    let inputs = [];
    try { inputs = await listCameras(); } catch { throw error; }
    for (const input of inputs) {
      if (!input.deviceId) continue;
      try { return await capture({deviceId: {exact: input.deviceId}}); }
      catch (specificError) { if (!missing(specificError)) throw specificError; }
    }
    throw error;
  }
}
