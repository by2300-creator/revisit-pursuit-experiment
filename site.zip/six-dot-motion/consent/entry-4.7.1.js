const studyPath = '/revisit-pursuit-experiment/six-dot-motion';
const path = location.pathname.replace(/\/+$/, '');
const url = new URL(location.href);
const runParameter = 'pursuitRun';
const sessionKey = 'six-dot-motion:active-session:4.7.1';
const loadStudy = () => import('../../assets/index-ee6b19527d2d.js');

function showFormError(root) {
  root.textContent = 'The study could not load. Reload this page to try again.';
}

async function verifyInvitation(token) {
  if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{110}$/.test(token)) return null;
  const bytes = Uint8Array.from(atob(token.replace(/-/g,'+').replace(/_/g,'/')), ch=>ch.charCodeAt(0));
  const key = await crypto.subtle.importKey('jwk', {"kty":"EC","x":"I8lb-4ON5QQiaBrL8SKsyRdhn8V7WzWP3VGtp_baagE","y":"AXt44HRNaC3rh-UECa_GPqLQl-d5ivdAKzfR0yr7mz0","crv":"P-256"}, {name:'ECDSA',namedCurve:'P-256'}, false, ['verify']);
  if (!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,bytes.subarray(18),bytes.subarray(0,18))) return null;
  const view = new DataView(bytes.buffer);
  const number = Number(view.getBigUint64(2) ^ view.getBigUint64(10));
  if (bytes[0] !== 1 || bytes[1] >= 6 || !Number.isSafeInteger(number) || number < 1) return null;
  return {number, tag:'ABCDEF'[bytes[1]]};
}

async function startParticipant(root) {
  const stylesheet = document.createElement('link');
  stylesheet.rel = 'stylesheet';
  stylesheet.href = new URL('./form.css', import.meta.url);
  document.head.append(stylesheet);

  // Reloading an active trial keeps its session. The public entrance always
  // begins a new one, even if this browser has records from a previous pilot.
  const token = new URLSearchParams(url.hash.slice(1)).get('invite');
  if (path !== studyPath) {
    const saved = JSON.parse(sessionStorage.getItem(sessionKey) || 'null');
    if (saved && saved.run === url.searchParams.get(runParameter)) {
      const assignment = await verifyInvitation(saved.token);
      if (assignment) {
        window.pursuitAssignment = assignment;
        window.pursuitConsent = saved.consent;
        window.pursuitProlificId = saved.prolificId;
        await loadStudy();
        return;
      }
    }
    url.pathname = studyPath + '/';
    url.searchParams.delete(runParameter);
    history.replaceState(null, '', url);
  }
  const assignment = await verifyInvitation(token);
  if (!assignment) {
    root.innerHTML = '<main class="consent-sheet"><h1>Study invitation needed</h1><p>Please open the individual study link sent to you by the research team. If you need a new link, contact the team.</p></main>';
    return;
  }
  for (const name of ['participantNumber','tag','cohort',runParameter]) url.searchParams.delete(name);
  history.replaceState(null, '', url);
  const response = await fetch(new URL('./form.html', import.meta.url));
  if (!response.ok) throw new Error('Consent unavailable');
  root.innerHTML = await response.text();
  root.querySelector('#disagree').onclick = () => {
    root.innerHTML = '<main class="consent-sheet"><h1 tabindex="-1">Session ended</h1><p>You declined to participate. You can close this tab.</p></main>';
    root.querySelector('h1').focus();
  };
  root.querySelector('#agree').onclick = () => {
    const consent = { decision: 'agreed', version: '2026-11-24.1', agreedAt: new Date().toISOString() };
    root.innerHTML = '<main class="consent-sheet"><form><label>Please provide your Prolific ID: <input required name="prolific" autocomplete="off"></label> <button>Next</button></form></main>';
    const form = root.querySelector('form');
    const field = form.elements.prolific;
    field.value = url.searchParams.get('PROLIFIC_PID') || '';
    field.focus();
    form.onsubmit = async event => {
      event.preventDefault();
      const prolificId = field.value.trim();
      if (!prolificId) { field.focus(); return; }
      try {
        const run = crypto.randomUUID();
        sessionStorage.setItem(sessionKey, JSON.stringify({ run, consent, prolificId, token }));
        url.hash = '';
        url.searchParams.set(runParameter, run);
        history.replaceState(null, '', url);
        window.pursuitConsent = consent;
        window.pursuitProlificId = prolificId;
        window.pursuitAssignment = assignment;
        root.replaceChildren();
        window.scrollTo(0, 0);
        await loadStudy();
      } catch { showFormError(root); }
    };
  };
}

const isParticipant = path === studyPath || path.startsWith(studyPath + '/');
if (path === studyPath) window.addEventListener('hashchange', () => location.reload());
if (isParticipant && !path.startsWith(studyPath + '/reviewer-') && !path.startsWith(studyPath + '/__')) {
  const root = document.getElementById('root');
  try { await startParticipant(root); } catch { showFormError(root); }
} else {
  await loadStudy();
}
document.addEventListener('keydown', event => {
  if (event.code !== 'Space' || event.repeat || event.target.closest('input,button,textarea,select,a,[contenteditable]')) return;
  if (!document.body.textContent.includes('[Spacebar / Next]')) return;
  const next = Array.from(document.querySelectorAll('button[type=submit]')).find(button => !button.disabled && button.textContent.trim() === 'Next');
  if (next) { event.preventDefault(); next.click(); }
});
