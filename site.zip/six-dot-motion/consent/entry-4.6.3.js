const studyPath = '/revisit-pursuit-experiment/six-dot-motion';
const path = location.pathname.replace(/\/+$/, '');
const url = new URL(location.href);
const runParameter = 'pursuitRun';
const sessionKey = 'six-dot-motion:active-session:4.6.3';
const loadStudy = () => import('../../assets/index-975483efc54d.js');

function showFormError(root) {
  root.textContent = 'The study could not load. Reload this page to try again.';
}

async function startParticipant(root) {
  const stylesheet = document.createElement('link');
  stylesheet.rel = 'stylesheet';
  stylesheet.href = new URL('./form.css', import.meta.url);
  document.head.append(stylesheet);

  // Reloading an active trial keeps its session. The public entrance always
  // begins a new one, even if this browser has records from a previous pilot.
  if (path !== studyPath) {
    const saved = JSON.parse(sessionStorage.getItem(sessionKey) || 'null');
    if (saved && saved.run === url.searchParams.get(runParameter)) {
      window.pursuitConsent = saved.consent;
      window.pursuitProlificId = saved.prolificId;
      await loadStudy();
      return;
    }
    url.pathname = studyPath + '/';
    url.searchParams.delete(runParameter);
    history.replaceState(null, '', url);
  }

  const response = await fetch(new URL('./form.html', import.meta.url));
  if (!response.ok) throw new Error('Consent unavailable');
  root.innerHTML = await response.text();
  root.querySelector('#disagree').onclick = () => {
    root.innerHTML = '<main class="consent-sheet"><h1 tabindex="-1">Session ended</h1><p>You declined to participate. You can close this tab.</p></main>';
    root.querySelector('h1').focus();
  };
  root.querySelector('#agree').onclick = () => {
    const consent = { decision: 'agreed', version: '2026-11-24.1', agreedAt: new Date().toISOString() };
    root.innerHTML = '<main class="consent-sheet"><form><label>Please provide your Prolific ID: <input required name="prolific" autocomplete="off"></label> <button>Next</button></form></main>';
    const form = root.querySelector('form');
    const field = form.elements.prolific;
    field.value = url.searchParams.get('PROLIFIC_PID') || '';
    field.focus();
    form.onsubmit = async event => {
      event.preventDefault();
      const prolificId = field.value.trim();
      if (!prolificId) { field.focus(); return; }
      try {
        const run = crypto.randomUUID();
        sessionStorage.setItem(sessionKey, JSON.stringify({ run, consent, prolificId }));
        url.searchParams.set(runParameter, run);
        history.replaceState(null, '', url);
        window.pursuitConsent = consent;
        window.pursuitProlificId = prolificId;
        root.replaceChildren();
        window.scrollTo(0, 0);
        await loadStudy();
      } catch { showFormError(root); }
    };
  };
}

const isParticipant = path === studyPath || path.startsWith(studyPath + '/');
if (isParticipant && !path.startsWith(studyPath + '/reviewer-') && !path.startsWith(studyPath + '/__')) {
  const root = document.getElementById('root');
  try { await startParticipant(root); } catch { showFormError(root); }
} else {
  await loadStudy();
}
document.addEventListener('keydown', event => {
  if (event.code !== 'Space' || event.repeat || event.target.closest('input,button,textarea,select,a,[contenteditable]')) return;
  if (!document.body.textContent.includes('[Spacebar / Next]')) return;
  const next = Array.from(document.querySelectorAll('button[type=submit]')).find(button => !button.disabled && button.textContent.trim() === 'Next');
  if (next) { event.preventDefault(); next.click(); }
});
