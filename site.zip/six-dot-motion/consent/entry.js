const studyPath = "/revisit-pursuit-experiment/six-dot-motion";
const path = location.pathname.replace(/\/+$/, "");
const participantRoute = path === studyPath || path.startsWith(studyPath + "/");
const calibrationRoute = path === studyPath + "/reviewer-sixDotCalibration";
const loadStudy = () => import("../../assets/index-975483efc54d.js");

if (!participantRoute || calibrationRoute) {
  await loadStudy();
} else {
  const root = document.getElementById("root");
  try {
    const stylesheet = document.createElement("link");
    stylesheet.rel = "stylesheet";
    stylesheet.href = new URL("./form.css", import.meta.url);
    document.head.append(stylesheet);
    const response = await fetch(new URL("./form.html", import.meta.url));
    if (!response.ok) throw new Error("Consent unavailable");
    root.innerHTML = await response.text();
    document.getElementById("disagree").addEventListener("click", () => {
      root.innerHTML = '<main class="consent-sheet"><h1 tabindex="-1">Session ended</h1><p>You declined to participate. You can close this tab.</p></main>';
      root.querySelector("h1").focus();
      window.scrollTo(0, 0);
    });
    document.getElementById("agree").addEventListener("click", async () => {
      window.pursuitConsent = Object.freeze({
        decision: "agreed",
        version: "2026-11-24.1",
        agreedAt: new Date().toISOString()
      });
      root.innerHTML = '<main class="consent-sheet"><form><label>Please provide your Prolific ID: <input required name="prolific" autocomplete="off"></label> <button>Next</button></form></main>';
      const form=root.querySelector("form");
      const field=form.elements.prolific;
      field.value=new URLSearchParams(location.search).get("PROLIFIC_PID") || "";
      field.focus();
      await new Promise(resolve=>form.addEventListener("submit",ev=>{
        ev.preventDefault();
        if(!field.value.trim()){field.focus();return;}
        window.pursuitProlificId=field.value.trim();
        resolve();
      }));
      root.replaceChildren();
      window.scrollTo(0, 0);
      try { await loadStudy(); } catch { root.textContent = "The study could not load. Reload this page to try again."; }
    }, { once: true });
  } catch {
    root.textContent = "The consent form could not load. Reload this page to try again.";
  }
}

document.addEventListener('keydown', event=>{
  if(event.code!=='Space'||event.repeat||event.target.closest('input,button,textarea,select,a,[contenteditable]'))return;
  if(!document.body.textContent.includes('[Spacebar / Next]'))return;
  const next=Array.from(document.querySelectorAll('button[type=submit]')).find(button=>!button.disabled&&button.textContent.trim()==='Next');
  if(next){event.preventDefault();next.click();}
});
